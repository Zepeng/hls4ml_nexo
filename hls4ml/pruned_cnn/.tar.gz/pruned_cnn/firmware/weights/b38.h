//Numpy array shape [2]
//Min 0.017942791805
//Max 0.017943140119
//Number of zeros 0

#ifndef B38_H_
#define B38_H_

#ifndef __SYNTHESIS__
dense_11_bias_t b38[2];
#else
dense_11_bias_t b38[2] = {0.0179427918, 0.0179431401};
#endif

#endif
